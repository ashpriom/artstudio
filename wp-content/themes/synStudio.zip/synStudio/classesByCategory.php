<?php
/**
 * @package WordPress
 * @subpackage SynStudio_Theme
 */
/*
Template Name: Classes By Category Page
 */
get_header(); ?>

	<!-- content: start -->
	<div id="content" class="classes-byCategory">
  
		<!-- column 1: start -->
				<?php while ( have_posts() ) : the_post(); ?>
     <?php echo "<h1>"; the_title(); echo "</h1>"; ?>
					<?php the_content(); ?>

				<?php endwhile; // end of the loop. ?> 
  <!-- column 1: end -->
  
  <!-- column 2: start -->
   <!-- Join Our Newsletter : start -->
   <?php
   $cat = 'General';
   $catID = get_cat_ID($cat);
   
   query_posts('cat=' . $catID);
   while (have_posts()) : the_post();
   
   $postID = get_the_ID();
   if ($postID = "145") {
   //echo $postID;
   echo "<div id='newsletter-box' class='info-box1Wrapper'>";
   echo "<div class='info-box1'>";
   echo '<h2>' . get_the_title() . '</h2>';
   echo "<div class='text'>";
   //echo "<p>";
   the_excerpt();
   //echo "</p>";
   the_content();
   echo "</div>";
   echo "</div>";
   echo "</div>";
   }
   
   endwhile;
    ?>	
   <!-- Join Our Newsletter : end -->
  <!-- column 2: end -->
  
	</div>
	<!-- content: end -->

<?php get_footer(); ?>




		
		