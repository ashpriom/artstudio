<?php
get_header(); 
$currentLang = qtrans_getLanguage(); 
?>

	<!-- content: start -->
	<div id="content" class="general-page podcast">
  <div id="col1">

     <?php while ( have_posts() ) : the_post(); ?>
 
      <?php echo "<h1>" . get_the_title() . "</h1>"; ?>

   <div class="podcast-boxWrapper">
    <div class="podcast-box">

<div class="podcontent">
<?php
 $postIDPodcast = get_the_ID();   
	echo "<div class='image-description'>"; 
	echo "<img width='178' height='300' alt='' src='".get_post_meta($postIDPodcast, 'podcastsImage', true)."'>";
	the_content();
	
	if ($currentLang == "en") {
		echo "<div class='alert'>".get_post_meta($postIDPodcast, 'podcastsAudioAlert_en', true)."</div>";
	}
	else {
		echo "<div class='alert'>".get_post_meta($postIDPodcast, 'podcastsAudioAlert_fr', true)."</div>";
	}
	echo "</div>";
?>

<?php echo get_post_meta($postIDPodcast, 'podcastsIframe', true); ?>
</div>

    </div>
   </div> 
     <?php endwhile; // end of the loop. ?>

  </div>
  <?php get_sidebar(); ?>	
	</div>
	<!-- content: end -->

<?php get_footer(); ?>