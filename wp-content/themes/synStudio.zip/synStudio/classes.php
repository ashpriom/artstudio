<?php
/**
 * @package WordPress
 * @subpackage SynStudio_Theme
 */
/*
Template Name: Classes Page
 */
	
$currentLang = qtrans_getLanguage(); 
	
get_header(); 
?>

	<!-- content: start -->
	<div id="content" class="classes-byCategory landing">

   <!-- title: start -->
     <?php while ( have_posts() ) : the_post(); ?>
      <?php echo "<h1>"; the_title(); echo "</h1>"; ?> 
      <?php the_content(); ?>     
     <?php endwhile; // end of the loop. ?> 
   <!-- title: end -->
  
<!-- column 1: start -->
  <div id="col1">

			<div class="info-box1Wrapper"> 
    <div class="info-box1">
     <?php 
     if ($currentLang=="en"){
      echo "<h2>Drawing</h2>";
     }  
     else {
      echo "<h2>Dessin</h2>";
     }
     ?>
     
     
<!-- classes : start -->
<?php  $cats = get_categories('child_of=4'); 
        foreach ($cats as $cat) :
            $this_category = get_category($cat);
            $args = array('category__in' => array($cat->term_id),'order' => 'ASC');
            $my_query = new WP_Query($args); 
            if ($my_query->have_posts()) : ?>
            
            <?php
            if ($cat->name=="Drawing") { 
              if ($this_category->category_parent != 0) { 
                while ($my_query->have_posts()) : $my_query->the_post(); 
                /*general loop output; for instance: */ 
                $postID = get_the_ID();
                //$string = get_the_title();
                //$string = strtolower($string);
                //$string = str_replace(' ', '', $string);
                echo "<div id='class-".$postID."' class='class-wrapper'>";
                echo get_post_meta($postID, 'shortDescription_' . $currentLang, true);
                echo "</div>";

                endwhile; 
              } 
            } ?>

            <?php else : 
                echo 'No Posts for '.$cat->name;                
            endif; 
       endforeach;     
?>
<!-- classes : end -->

    </div> 
   </div>
   
   <div class="info-box1Wrapper"> 
    <div class="info-box1">
     <?php 
     if ($currentLang=="en"){
      echo "<h2>Painting</h2>";
     }  
     else {
      echo "<h2>Peinture</h2>";
     }
     ?>

<!-- classes : start -->
<?php  $cats = get_categories('child_of=4'); 
        foreach ($cats as $cat) :
            $this_category = get_category($cat);
            $args = array('category__in' => array($cat->term_id), 'orderby' => 'date', 'order' => 'ASC');
            $my_query = new WP_Query($args); 
            if ($my_query->have_posts()) : ?>
            
            <?php
            if ($cat->name=="Painting") { 
              if ($this_category->category_parent != 0) { 
                while ($my_query->have_posts()) : $my_query->the_post(); 
                /*general loop output; for instance: */ 
                $postID = get_the_ID();
                //$string = get_the_title();
                //$string = strtolower($string);
                //$string = str_replace(' ', '', $string);
                echo "<div id='class-".$postID."' class='class-wrapper'>";
                echo get_post_meta($postID, 'shortDescription_' . $currentLang, true);
                echo "</div>";

                endwhile; 
              } 
            } ?>

            <?php else : 
                echo 'No Posts for '.$cat->name;                
            endif; 
       endforeach;     
?>
<!-- classes : end -->          
    </div>    	
   </div>

			<div class="info-box1Wrapper"> 
    <div class="info-box1">
     <?php 
     if ($currentLang=="en"){
      echo "<h2>Special Classes</h2>";
     }  
     else {
      echo "<h2>Cours SPÉCIAUX</h2>";
     }
     ?>
      
     <h2></h2>

<!-- classes : start -->
<?php  $cats = get_categories('child_of=4'); 
        foreach ($cats as $cat) :
            $this_category = get_category($cat);
            $args = array('category__in' => array($cat->term_id), 'orderby' => 'date', 'order' => 'ASC');
            $my_query = new WP_Query($args); 
            if ($my_query->have_posts()) : ?>
            
            <?php
            if ($cat->name=="Special Classes") { 
              if ($this_category->category_parent != 0) { 
                while ($my_query->have_posts()) : $my_query->the_post(); 
                /*general loop output; for instance: */ 
                $postID = get_the_ID();
                //$string = get_the_title();
                //$string = strtolower($string);
                //$string = str_replace(' ', '', $string);
                echo "<div id='class-".$postID."' class='class-wrapper'>";
                echo get_post_meta($postID, 'shortDescription_' . $currentLang, true);
                echo "</div>";

                endwhile; 
              } 
            } ?>

            <?php else : 
                echo 'No Posts for '.$cat->name;                
            endif; 
       endforeach;     
?>
<!-- classes : end -->

          
    </div>    
   </div>
     	
  </div>
  <!-- column 1: end -->
  
  <!-- column 2: start -->
   <!-- Join Our Newsletter : start -->
   <?php
   $cat = 'General';
   $catID = get_cat_ID($cat);
   
   query_posts('cat=' . $catID);
   while (have_posts()) : the_post();
   
   $postID = get_the_ID();
   if ($postID = "145") {
   //echo $postID;
   echo "<div id='newsletter-box' class='info-box1Wrapper'>";
   echo "<div class='info-box1'>";
   echo '<h2>' . get_the_title() . '</h2>';
   echo "<div class='text'>";
   //echo "<p>";
   the_excerpt();
   //echo "</p>";
   the_content();
   echo "</div>";
   echo "</div>";
   echo "</div>";
   }
   
   endwhile;
    ?>	
   <!-- Join Our Newsletter : end -->
  <!-- column 2: end -->
  
	</div>
	<!-- content: end -->

<?php get_footer(); ?>




		
		